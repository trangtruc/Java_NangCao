package bean.Chung;

public class DanSoHuyen {
	
	private Huyen huyen;
	private long danSo;
	private double tyLePhanTram;
	/**
	 * @return the huyen
	 */
	public Huyen getHuyen() {
		return huyen;
	}
	/**
	 * @param huyen the huyen to set
	 */
	public void setHuyen(Huyen huyen) {
		this.huyen = huyen;
	}
	/**
	 * @return the danSo
	 */
	public long getDanSo() {
		return danSo;
	}
	/**
	 * @param danSo the danSo to set
	 */
	public void setDanSo(long danSo) {
		this.danSo = danSo;
	}
	/**
	 * @return the tyLePhanTram
	 */
	public double getTyLePhanTram() {
		return tyLePhanTram;
	}
	/**
	 * @param tyLePhanTram the tyLePhanTram to set
	 */
	public void setTyLePhanTram(double tyLePhanTram) {
		this.tyLePhanTram = tyLePhanTram;
	}
	
	
}
