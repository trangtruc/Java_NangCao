package bean.Chung;

public class NhomMau {
	private String maNM;
	private String tenNM;
	public String getMaNM() {
		return maNM;
	}
	public void setMaNM(String maNM) {
		this.maNM = maNM;
	}
	public String getTenNM() {
		return tenNM;
	}
	public void setTenNM(String tenNM) {
		this.tenNM = tenNM;
	}
}
