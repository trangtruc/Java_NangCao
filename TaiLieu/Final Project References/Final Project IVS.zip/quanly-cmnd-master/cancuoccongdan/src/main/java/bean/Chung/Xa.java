package bean.Chung;


public class Xa {

	private String maXa;
	private String tenXa;
	private Huyen huyen;
	
	public String getMaXa() {
		return maXa;
	}
	public void setMaXa(String maXa) {
		this.maXa = maXa;
	}
	public String getTenXa() {
		return tenXa;
	}
	public void setTenXa(String tenXa) {
		this.tenXa = tenXa;
	}
	public Huyen getHuyen() {
		return huyen;
	}
	public void setHuyen(Huyen huyen) {
		this.huyen = huyen;
	}
	
}
