package bean.Vu;

import java.io.InputStream;

public class TTDKCCCD extends CCCD {
	private int maSo;
	private int maYeuCau;
	private int chuyenPhat;
	private String ngayDK;
	private String noiDKLamViec;
	private String ngayHen;
	private String ngayXacNhan;
	private int duyet;
	private String lyDo;
	private String soKhaiSinh;
	private String maDuyet;
	private String nguoiKiemTra;
	private String ketQuaXacMinh;
	private  InputStream hinhAnh;
	public int getMaSo() {
		return maSo;
	}
	public void setMaSo(int maSO) {
		this.maSo = maSO;
	}
	public int getMaYeuCau() {
		return maYeuCau;
	}
	public void setMaYeuCau(Integer yeuCau) {
		this.maYeuCau = yeuCau;
	}
	public Integer getChuyenPhat() {
		return chuyenPhat;
	}
	public void setChuyenPhat(Integer chuyenPhat) {
		this.chuyenPhat = chuyenPhat;
	}
	public String getNoiDKLamViec() {
		return noiDKLamViec;
	}
	public void setNoiDKLamViec(String noiDKLamViec) {
		this.noiDKLamViec = noiDKLamViec;
	}
	public String getNgayHen() {
		return ngayHen;
	}
	public void setNgayHen(String ngayHen) {
		this.ngayHen = ngayHen;
	}
	public int getDuyet() {
		return duyet;
	}
	public void setDuyet(int duyet) {
		this.duyet = duyet;
	}
	public String getLyDo() {
		return lyDo;
	}
	public void setLyDo(String lyDo) {
		this.lyDo = lyDo;
	}
	public String getNgayDK() {
		return ngayDK;
	}
	public void setNgayDK(String ngayDK) {
		this.ngayDK = ngayDK;
	}
	public String getSoKhaiSinh() {
		return soKhaiSinh;
	}
	public void setSoKhaiSinh(String soKhaiSinh) {
		this.soKhaiSinh = soKhaiSinh;
	}
	/**
	 * @return the maDuyet
	 */
	public String getMaDuyet() {
		return maDuyet;
	}
	/**
	 * @param maDuyet the maDuyet to set
	 */
	public void setMaDuyet(String maDuyet) {
		this.maDuyet = maDuyet;
	}
	/**
	 * @return the nguoiKiemTra
	 */
	public String getNguoiKiemTra() {
		return nguoiKiemTra;
	}
	/**
	 * @param nguoiKiemTra the nguoiKiemTra to set
	 */
	public void setNguoiKiemTra(String nguoiKiemTra) {
		this.nguoiKiemTra = nguoiKiemTra;
	}
	/**
	 * @return the ngayXacNhan
	 */
	public String getNgayXacNhan() {
		return ngayXacNhan;
	}
	/**
	 * @param ngayXacNhan the ngayXacNhan to set
	 */
	public void setNgayXacNhan(String ngayXacNhan) {
		this.ngayXacNhan = ngayXacNhan;
	}
	/**
	 * @return the hinhAnh
	 */
	public InputStream getHinhAnh() {
		return hinhAnh;
	}
	/**
	 * @param hinhAnh the hinhAnh to set
	 */
	public void setHinhAnh(InputStream hinhAnh) {
		this.hinhAnh = hinhAnh;
	}
	/**
	 * @return the ketQuaXacMinh
	 */
	public String getKetQuaXacMinh() {
		return ketQuaXacMinh;
	}
	/**
	 * @param ketQuaXacMinh the ketQuaXacMinh to set
	 */
	public void setKetQuaXacMinh(String ketQuaXacMinh) {
		this.ketQuaXacMinh = ketQuaXacMinh;
	}
}
