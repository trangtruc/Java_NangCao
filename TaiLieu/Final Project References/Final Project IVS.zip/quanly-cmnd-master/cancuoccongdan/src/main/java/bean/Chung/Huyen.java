package bean.Chung;


public class Huyen {
	
	private String maHuyen;
	private String tenHuyen;
	private Tinh tinh;
	
	public String getMaHuyen() {
		return maHuyen;
	}
	public void setMaHuyen(String maHuyen) {
		this.maHuyen = maHuyen;
	}
	public String getTenHuyen() {
		return tenHuyen;
	}
	public void setTenHuyen(String tenHuyen) {
		this.tenHuyen = tenHuyen;
	}
	public Tinh getTinh() {
		return tinh;
	}
	public void setTinh(Tinh tinh) {
		this.tinh = tinh;
	}
	
	
}
