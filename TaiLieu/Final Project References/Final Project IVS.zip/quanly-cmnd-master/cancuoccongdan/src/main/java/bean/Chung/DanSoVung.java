package bean.Chung;

public class DanSoVung {
	private Vung vung;
	private long danSo;
	private double tyLePhanTram;
	/**
	 * @return the vung
	 */
	public Vung getVung() {
		return vung;
	}
	/**
	 * @param vung the vung to set
	 */
	public void setVung(Vung vung) {
		this.vung = vung;
	}
	/**
	 * @return the danSo
	 */
	public long getDanSo() {
		return danSo;
	}
	/**
	 * @param danSo the danSo to set
	 */
	public void setDanSo(long danSo) {
		this.danSo = danSo;
	}
	/**
	 * @return the tyLePhanTram
	 */
	public double getTyLePhanTram() {
		return tyLePhanTram;
	}
	/**
	 * @param tyLePhanTram the tyLePhanTram to set
	 */
	public void setTyLePhanTram(double tyLePhanTram) {
		this.tyLePhanTram = tyLePhanTram;
	}
	
}
