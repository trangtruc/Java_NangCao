package bean.An;

public class DSThemNhanKhau {
	private String soHKMoi;
	private String soHKCU;
	private String soKS;
	private String soCC;
	private String quanHe;
	private String ngayDuyet;
	private String ngayDangKy;
	private String noiDangKyLamViec;
	private String nguoiDuyet;
	private String lyDo;
	private String duyet;
	private String tinhTrang;
	private String ngayHen;
	public String getSoHKMoi() {
		return soHKMoi;
	}
	public void setSoHKMoi(String soHKMoi) {
		this.soHKMoi = soHKMoi;
	}
	public String getSoHKCU() {
		return soHKCU;
	}
	public void setSoHKCU(String soHKCU) {
		this.soHKCU = soHKCU;
	}
	public String getSoKS() {
		return soKS;
	}
	public void setSoKS(String soKS) {
		this.soKS = soKS;
	}
	public String getSoCC() {
		return soCC;
	}
	public void setSoCC(String soCC) {
		this.soCC = soCC;
	}
	public String getQuanHe() {
		return quanHe;
	}
	public void setQuanHe(String quanHe) {
		this.quanHe = quanHe;
	}
	public String getNgayDuyet() {
		return ngayDuyet;
	}
	public void setNgayDuyet(String ngayDuyet) {
		this.ngayDuyet = ngayDuyet;
	}
	public String getNgayDangKy() {
		return ngayDangKy;
	}
	public void setNgayDangKy(String ngayDangKy) {
		this.ngayDangKy = ngayDangKy;
	}
	public String getNoiDangKyLamViec() {
		return noiDangKyLamViec;
	}
	public void setNoiDangKyLamViec(String noiDangKyLamViec) {
		this.noiDangKyLamViec = noiDangKyLamViec;
	}
	public String getNguoiDuyet() {
		return nguoiDuyet;
	}
	public void setNguoiDuyet(String nguoiDuyet) {
		this.nguoiDuyet = nguoiDuyet;
	}
	public String getDuyet() {
		return duyet;
	}
	public void setDuyet(String duyet) {
		this.duyet = duyet;
	}
	public String getLyDo() {
		return lyDo;
	}
	public void setLyDo(String lyDo) {
		this.lyDo = lyDo;
	}
	public String getTinhTrang() {
		return tinhTrang;
	}
	public void setTinhTrang(String tinhTrang) {
		this.tinhTrang = tinhTrang;
	}
	public String getNgayHen() {
		return ngayHen;
	}
	public void setNgayHen(String ngayHen) {
		this.ngayHen = ngayHen;
	}
	
}
