package bean.An;

public class LienKetDuLieu {
	private int maSo;
	private String soCC;
	private String soKS;
	public int getMaSo() {
		return maSo;
	}
	public void setMaSo(int maSo) {
		this.maSo = maSo;
	}
	public String getSoCC() {
		return soCC;
	}
	public void setSoCC(String soCC) {
		this.soCC = soCC;
	}
	public String getSoKS() {
		return soKS;
	}
	public void setSoKS(String soKS) {
		this.soKS = soKS;
	}
	
}
