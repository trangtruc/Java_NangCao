package bean.Vu;

public class TheCMT extends CCCD{
	private String stt;
	private String maSo;
	private String password;
	private String nguoiTra;
	private String ngayTra;
	private String noiTra;
	private String hanSD;
	private String nguoiNhan;
	private String queQuan;
	private int daLam;
	private int daTra;
	public String getNguoiTra() {
		return nguoiTra;
	}
	public void setNguoiTra(String nguoiTra) {
		this.nguoiTra = nguoiTra;
	}
	public String getNgayTra() {
		return ngayTra;
	}
	public void setNgayTra(String ngayTra) {
		this.ngayTra = ngayTra;
	}
	/**
	 * @return the hanSD
	 */
	public String getHanSD() {
		return hanSD;
	}
	/**
	 * @param hanSD the hanSD to set
	 */
	public void setHanSD(String hanSD) {
		this.hanSD = hanSD;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the nguoiNhan
	 */
	public String getNguoiNhan() {
		return nguoiNhan;
	}
	/**
	 * @param nguoiNhan the nguoiNhan to set
	 */
	public void setNguoiNhan(String nguoiNhan) {
		this.nguoiNhan = nguoiNhan;
	}
	/**
	 * @return the maSo
	 */
	public String getMaSo() {
		return maSo;
	}
	/**
	 * @param maSo the maSo to set
	 */
	public void setMaSo(String maSo) {
		this.maSo = maSo;
	}
	/**
	 * @return the stt
	 */
	public String getStt() {
		return stt;
	}
	/**
	 * @param stt the stt to set
	 */
	public void setStt(String stt) {
		this.stt = stt;
	}
	/**
	 * @return the noiTra
	 */
	public String getNoiTra() {
		return noiTra;
	}
	/**
	 * @param noiTra the noiTra to set
	 */
	public void setNoiTra(String noiTra) {
		this.noiTra = noiTra;
	}
	/**
	 * @return the queQuan
	 */
	public String getQueQuan() {
		return queQuan;
	}
	/**
	 * @param queQuan the queQuan to set
	 */
	public void setQueQuan(String queQuan) {
		this.queQuan = queQuan;
	}
	/**
	 * @return the daLam
	 */
	public int getDaLam() {
		return daLam;
	}
	/**
	 * @param daLam the daLam to set
	 */
	public void setDaLam(int daLam) {
		this.daLam = daLam;
	}
	/**
	 * @return the daTra
	 */
	public int getDaTra() {
		return daTra;
	}
	/**
	 * @param daTra the daTra to set
	 */
	public void setDaTra(int daTra) {
		this.daTra = daTra;
	}
}
