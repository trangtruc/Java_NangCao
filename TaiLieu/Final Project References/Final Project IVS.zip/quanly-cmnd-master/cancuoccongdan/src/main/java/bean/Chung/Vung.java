package bean.Chung;

public class Vung {
	
	private int maVung;
	private String tenVung;
	
	/**
	 * @return the maVung
	 */
	public int getMaVung() {
		return maVung;
	}
	/**
	 * @param maVung the maVung to set
	 */
	public void setMaVung(int maVung) {
		this.maVung = maVung;
	}
	/**
	 * @return the tenVung
	 */
	public String getTenVung() {
		return tenVung;
	}
	/**
	 * @param tenVung the tenVung to set
	 */
	public void setTenVung(String tenVung) {
		this.tenVung = tenVung;
	}
}
