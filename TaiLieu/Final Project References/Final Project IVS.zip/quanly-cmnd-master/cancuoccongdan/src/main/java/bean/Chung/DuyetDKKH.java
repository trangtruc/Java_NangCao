package bean.Chung;

public class DuyetDKKH {
	
	private int soDK;
	private String ngayDuocDuyet;
	private String nguoiDuyet;
	private String ghiChu;
	
	public int getSoDK() {
		return soDK;
	}
	public void setSoDK(int soDK) {
		this.soDK = soDK;
	}
	public String getNgayDuocDuyet() {
		return ngayDuocDuyet;
	}
	public void setNgayDuocDuyet(String ngayDuocDuyet) {
		this.ngayDuocDuyet = ngayDuocDuyet;
	}
	public String getNguoiDuyet() {
		return nguoiDuyet;
	}
	public void setNguoiDuyet(String nguoiDuyet) {
		this.nguoiDuyet = nguoiDuyet;
	}
	public String getGhiChu() {
		return ghiChu;
	}
	public void setGhiChu(String ghiChu) {
		this.ghiChu = ghiChu;
	}
	
}
