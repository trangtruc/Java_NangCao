package com.mkyong.dao;

import bean.Config.ConfigKetHon;

public interface ConfigKetHonDao {
	ConfigKetHon getConfigKetHon();
	Boolean updateConfigKetHon(ConfigKetHon ck);
}
