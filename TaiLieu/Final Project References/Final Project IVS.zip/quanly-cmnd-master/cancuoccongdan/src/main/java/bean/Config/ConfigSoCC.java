package bean.Config;

public class ConfigSoCC {
	private int nam;
	private String moTa;
	private int giaTriNamTruoc;
	private int giaTriNuTruoc;
	private int giaTriNamSau;
	private int giaTriNuSau;
	public int getGiaTriNamTruoc() {
		return giaTriNamTruoc;
	}
	public void setGiaTriNamTruoc(int giaTriNamTruoc) {
		this.giaTriNamTruoc = giaTriNamTruoc;
	}
	public int getGiaTriNuTruoc() {
		return giaTriNuTruoc;
	}
	public void setGiaTriNuTruoc(int giaTriNuTruoc) {
		this.giaTriNuTruoc = giaTriNuTruoc;
	}
	public int getGiaTriNamSau() {
		return giaTriNamSau;
	}
	public void setGiaTriNamSau(int giaTriNamSau) {
		this.giaTriNamSau = giaTriNamSau;
	}
	public int getGiaTriNuSau() {
		return giaTriNuSau;
	}
	public void setGiaTriNuSau(int giaTriNuSau) {
		this.giaTriNuSau = giaTriNuSau;
	}
	public int getNam() {
		return nam;
	}
	public void setNam(int truocNam) {
		this.nam = truocNam;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
}
