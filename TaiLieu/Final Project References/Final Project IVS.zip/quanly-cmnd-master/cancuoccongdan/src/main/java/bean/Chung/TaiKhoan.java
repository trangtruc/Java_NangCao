package bean.Chung;


public class TaiKhoan {
	private String username;
	private String password;
	private String email;
	private String soDienThoai;
	private String trangThai;
	private String hoTen;
	private String coQuan;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSoDienThoai() {
		return soDienThoai;
	}
	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}
	public String getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(String trangThai) {
		this.trangThai = trangThai;
	}
	public String getHoTen() {
		return hoTen;
	}
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	/**
	 * @return the coQuan
	 */
	public String getCoQuan() {
		return coQuan;
	}
	/**
	 * @param coQuan the coQuan to set
	 */
	public void setCoQuan(String coQuan) {
		this.coQuan = coQuan;
	}
}
