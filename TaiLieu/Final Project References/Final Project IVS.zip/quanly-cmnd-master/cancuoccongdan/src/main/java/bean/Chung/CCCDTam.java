package bean.Chung;

public class CCCDTam extends CCCD {
	private int maSo;
	private int maYeuCau;
	private int chuyenPhat;
	private Huyen noiDKLamViec;
	private String ngayHen;
	
	public int getMaSo() {
		return maSo;
	}
	public void setMaSo(int maSo) {
		this.maSo = maSo;
	}
	public int getMaYeuCau() {
		return maYeuCau;
	}
	public void setMaYeuCau(int maYeuCau) {
		this.maYeuCau = maYeuCau;
	}
	public int getChuyenPhat() {
		return chuyenPhat;
	}
	public void setChuyenPhat(int chuyenPhat) {
		this.chuyenPhat = chuyenPhat;
	}
	public Huyen getNoiDKLamViec() {
		return noiDKLamViec;
	}
	public void setNoiDKLamViec(Huyen noiDKLamViec) {
		this.noiDKLamViec = noiDKLamViec;
	}
	public String getNgayHen() {
		return ngayHen;
	}
	public void setNgayHen(String ngayHen) {
		this.ngayHen = ngayHen;
	}
	
	
}
