package bean.Config;

public class ConfigNgayNghi {
	
	private int ngay;
	private int thang;
	/**
	 * @return the ngay
	 */
	public int getNgay() {
		return ngay;
	}
	/**
	 * @param ngay the ngay to set
	 */
	public void setNgay(int ngay) {
		this.ngay = ngay;
	}
	/**
	 * @return the thang
	 */
	public int getThang() {
		return thang;
	}
	/**
	 * @param thang the thang to set
	 */
	public void setThang(int thang) {
		this.thang = thang;
	}
}
