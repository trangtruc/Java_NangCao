package bean.Chung;

public class DuyetDKKS {
	
	private int soDK;
	private String soKS;
	private String ngayDuocDuyet;
	private String nguoiDuyet;
	private String ghiChu;
	
	/**
	 * @return the soDK
	 */
	public int getSoDK() {
		return soDK;
	}
	/**
	 * @param soDK the soDK to set
	 */
	public void setSoDK(int soDK) {
		this.soDK = soDK;
	}
	/**
	 * @return the soKS
	 */
	public String getSoKS() {
		return soKS;
	}
	/**
	 * @param soKS the soKS to set
	 */
	public void setSoKS(String soKS) {
		this.soKS = soKS;
	}
	/**
	 * @return the ngayDuocDuyet
	 */
	public String getNgayDuocDuyet() {
		return ngayDuocDuyet;
	}
	/**
	 * @param ngayDuocDuyet the ngayDuocDuyet to set
	 */
	public void setNgayDuocDuyet(String ngayDuocDuyet) {
		this.ngayDuocDuyet = ngayDuocDuyet;
	}
	/**
	 * @return the nguoiDuyet
	 */
	public String getNguoiDuyet() {
		return nguoiDuyet;
	}
	/**
	 * @param nguoiDuyet the nguoiDuyet to set
	 */
	public void setNguoiDuyet(String nguoiDuyet) {
		this.nguoiDuyet = nguoiDuyet;
	}
	/**
	 * @return the ghiChu
	 */
	public String getGhiChu() {
		return ghiChu;
	}
	/**
	 * @param ghiChu the ghiChu to set
	 */
	public void setGhiChu(String ghiChu) {
		this.ghiChu = ghiChu;
	}
	
}
