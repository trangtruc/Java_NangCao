package com.mkyong.services;

import bean.Config.ConfigKetHon;

public interface ConfigKetHonService {
	ConfigKetHon getConfigKetHon();
	Boolean updateConfigKetHon(ConfigKetHon ck);
}
