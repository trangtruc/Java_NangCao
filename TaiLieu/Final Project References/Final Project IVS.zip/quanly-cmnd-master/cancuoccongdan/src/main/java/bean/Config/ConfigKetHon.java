package bean.Config;

public class ConfigKetHon {
	private int tuoiNam;
	private int tuoiNu;
	public int getTuoiNam() {
		return tuoiNam;
	}
	public void setTuoiNam(int tuoiNam) {
		this.tuoiNam = tuoiNam;
	}
	public int getTuoiNu() {
		return tuoiNu;
	}
	public void setTuoiNu(int tuoiNu) {
		this.tuoiNu = tuoiNu;
	}
}
