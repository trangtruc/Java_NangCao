package bean.Chung;

public class DanSoXa {
	private Xa xa;
	private long danSo;
	private double tyLePhanTram;
	/**
	 * @return the xa
	 */
	public Xa getXa() {
		return xa;
	}
	/**
	 * @param xa the xa to set
	 */
	public void setXa(Xa xa) {
		this.xa = xa;
	}
	/**
	 * @return the danSo
	 */
	public long getDanSo() {
		return danSo;
	}
	/**
	 * @param danSo the danSo to set
	 */
	public void setDanSo(long danSo) {
		this.danSo = danSo;
	}
	/**
	 * @return the tyLePhanTram
	 */
	public double getTyLePhanTram() {
		return tyLePhanTram;
	}
	/**
	 * @param tyLePhanTram the tyLePhanTram to set
	 */
	public void setTyLePhanTram(double tyLePhanTram) {
		this.tyLePhanTram = tyLePhanTram;
	}
	
}
