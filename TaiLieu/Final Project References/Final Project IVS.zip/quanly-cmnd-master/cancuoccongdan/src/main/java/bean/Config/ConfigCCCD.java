package bean.Config;

public class ConfigCCCD {
	private int hanHoSo;
	private int hanSuDung;
	private int soHoSo1Ngay;
	private int tuoi;
	public int getHanHoSo() {
		return hanHoSo;
	}
	public void setHanHoSo(int hanHoSo) {
		this.hanHoSo = hanHoSo;
	}
	public int getHanSuDung() {
		return hanSuDung;
	}
	public void setHanSuDung(int hanSuDung) {
		this.hanSuDung = hanSuDung;
	}
	public int getSoHoSo1Ngay() {
		return soHoSo1Ngay;
	}
	public void setSoHoSo1Ngay(int soHoSo1Ngay) {
		this.soHoSo1Ngay = soHoSo1Ngay;
	}
	/**
	 * @return the tuoi
	 */
	public int getTuoi() {
		return tuoi;
	}
	/**
	 * @param tuoi the tuoi to set
	 */
	public void setTuoi(int tuoi) {
		this.tuoi = tuoi;
	}
}
