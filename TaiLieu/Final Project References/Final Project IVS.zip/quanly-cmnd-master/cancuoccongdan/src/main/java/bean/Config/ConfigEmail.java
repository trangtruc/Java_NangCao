package bean.Config;


public class ConfigEmail {
	private String maEmail;
	private String email;
	private String matKhau;
	private String tieuDeGui;
	private String noiDungGui;
	public String getMaEmail() {
		return maEmail;
	}
	public void setMaEmail(String maEmail) {
		this.maEmail = maEmail;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMatKhau() {
		return matKhau;
	}
	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}
	public String getNoiDungGui() {
		return noiDungGui;
	}
	public void setNoiDungGui(String noiDungGui) {
		this.noiDungGui = noiDungGui;
	}
	public String getTieuDeGui() {
		return tieuDeGui;
	}
	public void setTieuDeGui(String tieuDeGui) {
		this.tieuDeGui = tieuDeGui;
	}
}
