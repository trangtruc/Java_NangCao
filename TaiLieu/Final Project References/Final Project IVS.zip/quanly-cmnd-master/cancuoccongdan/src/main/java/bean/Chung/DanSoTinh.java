package bean.Chung;

public class DanSoTinh {
	
	private Tinh tinh;
	private long danSo;
	private double tyLePhanTram;
	/**
	 * @return the tinh
	 */
	public Tinh getTinh() {
		return tinh;
	}
	/**
	 * @param tinh the tinh to set
	 */
	public void setTinh(Tinh tinh) {
		this.tinh = tinh;
	}
	/**
	 * @return the danSo
	 */
	public long getDanSo() {
		return danSo;
	}
	/**
	 * @param danSo the danSo to set
	 */
	public void setDanSo(long danSo) {
		this.danSo = danSo;
	}
	/**
	 * @return the tyLePhanTram
	 */
	public double getTyLePhanTram() {
		return tyLePhanTram;
	}
	/**
	 * @param tyLePhanTram the tyLePhanTram to set
	 */
	public void setTyLePhanTram(double tyLePhanTram) {
		this.tyLePhanTram = tyLePhanTram;
	}
	
	
}
