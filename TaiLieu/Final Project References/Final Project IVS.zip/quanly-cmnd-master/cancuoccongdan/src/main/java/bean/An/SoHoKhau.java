package bean.An;

public class SoHoKhau {
	private String soCC;
	private String soHK;
	private String soKS;
	private String diaChi;
	private String quanHe;
	private String tinhTrang;
	private String ngayChuyenDen;
	public String getSoCC() {
		return soCC;
	}
	public void setSoCC(String soCC) {
		this.soCC = soCC;
	}
	public String getSoHK() {
		return soHK;
	}
	public void setSoHK(String soHK) {
		this.soHK = soHK;
	}
	public String getQuanHe() {
		return quanHe;
	}
	public void setQuanHe(String quanHe) {
		this.quanHe = quanHe;
	}
	public String getDiaChi() {
		return diaChi;
	}
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	/**
	 * @return the soKS
	 */
	public String getSoKS() {
		return soKS;
	}
	/**
	 * @param soKS the soKS to set
	 */
	public void setSoKS(String soKS) {
		this.soKS = soKS;
	}
	public String getTinhTrang() {
		return tinhTrang;
	}
	public void setTinhTrang(String tinhTrang) {
		this.tinhTrang = tinhTrang;
	}
	public String getNgayChuyenDen() {
		return ngayChuyenDen;
	}
	public void setNgayChuyenDen(String ngayChuyenDen) {
		this.ngayChuyenDen = ngayChuyenDen;
	}
}
