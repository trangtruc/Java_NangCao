package bean.Chung;

public class Quyen {
	private int maQuyen;
	private String tenQuyen;
	private String moTaQuyen;
	public int getMaQuyen() {
		return maQuyen;
	}
	public void setMaQuyen(int maQuyen) {
		this.maQuyen = maQuyen;
	}
	public String getTenQuyen() {
		return tenQuyen;
	}
	public void setTenQuyen(String tenQuyen) {
		this.tenQuyen = tenQuyen;
	}
	/**
	 * @return the moTaQuyen
	 */
	public String getMoTaQuyen() {
		return moTaQuyen;
	}
	/**
	 * @param moTaQuyen the moTaQuyen to set
	 */
	public void setMoTaQuyen(String moTaQuyen) {
		this.moTaQuyen = moTaQuyen;
	}
}
