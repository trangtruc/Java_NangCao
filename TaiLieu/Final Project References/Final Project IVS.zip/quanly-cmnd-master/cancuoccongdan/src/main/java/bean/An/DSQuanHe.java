package bean.An;

public class DSQuanHe {
	private String quanHe;
	private String tenQuanHe;
	public String getTenQuanHe() {
		return tenQuanHe;
	}
	public void setTenQuanHe(String tenQuanHe) {
		this.tenQuanHe = tenQuanHe;
	}
	public String getQuanHe() {
		return quanHe;
	}
	public void setQuanHe(String quanHe) {
		this.quanHe = quanHe;
	}
	
	
	
}
