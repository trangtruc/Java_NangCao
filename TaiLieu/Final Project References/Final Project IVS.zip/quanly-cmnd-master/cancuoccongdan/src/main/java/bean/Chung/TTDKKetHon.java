package bean.Chung;

public class TTDKKetHon {
	
	private String soDK;
	private String soCCNguoiDK;
	private String soCCVoHoacChong;
	private String ngayDangKy;
	private String ngayHenLamViec;
	private int trangThai;
	private String noiDKLV;
	private long maXacNhan;
	private String ghiChu;
	
	/**
	 * @return the soDK
	 */
	public String getSoDK() {
		return soDK;
	}
	/**
	 * @param soDK the soDK to set
	 */
	public void setSoDK(String soDK) {
		this.soDK = soDK;
	}
	/**
	 * @return the soCCNguoiDK
	 */
	public String getSoCCNguoiDK() {
		return soCCNguoiDK;
	}
	/**
	 * @param soCCNguoiDK the soCCNguoiDK to set
	 */
	public void setSoCCNguoiDK(String soCCNguoiDK) {
		this.soCCNguoiDK = soCCNguoiDK;
	}
	/**
	 * @return the soCCVoHoacChong
	 */
	public String getSoCCVoHoacChong() {
		return soCCVoHoacChong;
	}
	/**
	 * @param soCCVoHoacChong the soCCVoHoacChong to set
	 */
	public void setSoCCVoHoacChong(String soCCVoHoacChong) {
		this.soCCVoHoacChong = soCCVoHoacChong;
	}
	/**
	 * @return the ngayDangKy
	 */
	public String getNgayDangKy() {
		return ngayDangKy;
	}
	/**
	 * @param ngayDangKy the ngayDangKy to set
	 */
	public void setNgayDangKy(String ngayDangKy) {
		this.ngayDangKy = ngayDangKy;
	}
	/**
	 * @return the ngayHenLamViec
	 */
	public String getNgayHenLamViec() {
		return ngayHenLamViec;
	}
	/**
	 * @param ngayHenLamViec the ngayHenLamViec to set
	 */
	public void setNgayHenLamViec(String ngayHenLamViec) {
		this.ngayHenLamViec = ngayHenLamViec;
	}
	/**
	 * @return the trangThai
	 */
	public int getTrangThai() {
		return trangThai;
	}
	/**
	 * @param trangThai the trangThai to set
	 */
	public void setTrangThai(int trangThai) {
		this.trangThai = trangThai;
	}
	/**
	 * @return the noiDKLV
	 */
	public String getNoiDKLV() {
		return noiDKLV;
	}
	/**
	 * @param noiDKLV the noiDKLV to set
	 */
	public void setNoiDKLV(String noiDKLV) {
		this.noiDKLV = noiDKLV;
	}
	/**
	 * @return the maXacNhan
	 */
	public long getMaXacNhan() {
		return maXacNhan;
	}
	/**
	 * @param maXacNhan the maXacNhan to set
	 */
	public void setMaXacNhan(long maXacNhan) {
		this.maXacNhan = maXacNhan;
	}
	/**
	 * @return the ghiChu
	 */
	public String getGhiChu() {
		return ghiChu;
	}
	/**
	 * @param ghiChu the ghiChu to set
	 */
	public void setGhiChu(String ghiChu) {
		this.ghiChu = ghiChu;
	}
	
	
}
