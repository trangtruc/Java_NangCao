package bean.Chung;

public class HonNhan {
	
	private String soDK;
	private String soCCChong;
	private String soCCVo;
	private TinhTrangHN tinhTrangHN;
	private String ghiChu;
	
	public String getSoCCChong() {
		return soCCChong;
	}
	public void setSoCCChong(String soCCChong) {
		this.soCCChong = soCCChong;
	}
	public String getSoCCVo() {
		return soCCVo;
	}
	public void setSoCCVo(String soCCVo) {
		this.soCCVo = soCCVo;
	}
	public TinhTrangHN getTinhTrangHN() {
		return tinhTrangHN;
	}
	public void setTinhTrangHN(TinhTrangHN tinhTrangHN) {
		this.tinhTrangHN = tinhTrangHN;
	}
	public String getSoDK() {
		return soDK;
	}
	public void setSoDK(String soDK) {
		this.soDK = soDK;
	}
	public String getGhiChu() {
		return ghiChu;
	}
	public void setGhiChu(String ghiChu) {
		this.ghiChu = ghiChu;
	}
}
