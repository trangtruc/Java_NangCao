package bean.An;

public class DSLamHoKhau {
	private String maSo;
	private String soHKCu;
	private String soCCNguoiDK;
	private String diaChi;
	private String soKSThanhVien;
	private String SoCCThanhVien;
	private String quanHe;
	private String duyet;
	private String lydo;
	private String tinhTrang;
	public String getMaSo() {
		return maSo;
	}
	public void setMaSo(String maSo) {
		this.maSo = maSo;
	}
	public String getSoCCNguoiDK() {
		return soCCNguoiDK;
	}
	public void setSoCCNguoiDK(String soCCNguoiDK) {
		this.soCCNguoiDK = soCCNguoiDK;
	}
	public String getDiaChi() {
		return diaChi;
	}
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	public String getSoKSThanhVien() {
		return soKSThanhVien;
	}
	public void setSoKSThanhVien(String soKSThanhVien) {
		this.soKSThanhVien = soKSThanhVien;
	}
	public String getSoCCThanhVien() {
		return SoCCThanhVien;
	}
	public void setSoCCThanhVien(String soCCThanhVien) {
		SoCCThanhVien = soCCThanhVien;
	}
	public String getQuanHe() {
		return quanHe;
	}
	public void setQuanHe(String quanHe) {
		this.quanHe = quanHe;
	}
	public String getSoHKCu() {
		return soHKCu;
	}
	public void setSoHKCu(String soHKCu) {
		this.soHKCu = soHKCu;
	}
	public String getDuyet() {
		return duyet;
	}
	public void setDuyet(String duyet) {
		this.duyet = duyet;
	}
	public String getLydo() {
		return lydo;
	}
	public void setLydo(String lydo) {
		this.lydo = lydo;
	}
	public String getTinhTrang() {
		return tinhTrang;
	}
	public void setTinhTrang(String tinhTrang) {
		this.tinhTrang = tinhTrang;
	}
	
}
