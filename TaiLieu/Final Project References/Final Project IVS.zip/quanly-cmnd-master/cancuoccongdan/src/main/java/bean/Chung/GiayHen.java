package bean.Chung;

public class GiayHen {
	private String maSo;
	private String hoTen;
	private String ngaySinh;
	private String ngayHen;
	private String diaDiem;
	private String giayTo;
	public String getMaSo() {
		return maSo;
	}
	public void setMaSo(String maSo) {
		this.maSo = maSo;
	}
	public String getHoTen() {
		return hoTen;
	}
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	public String getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(String ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public String getNgayHen() {
		return ngayHen;
	}
	public void setNgayHen(String ngayHen) {
		this.ngayHen = ngayHen;
	}
	public String getDiaDiem() {
		return diaDiem;
	}
	public void setDiaDiem(String diaDiem) {
		this.diaDiem = diaDiem;
	}
	public String getGiayTo() {
		return giayTo;
	}
	public void setGiayTo(String giayTo) {
		this.giayTo = giayTo;
	}
}
