package bean.Chung;

public class YeuCau {
	private int maYeuCau;
	private String tenYeuCau;
	private String moTa;
	private String giayTo;
	private int lePhi;
	private String tinhTrang;
	public int getMaYeuCau() {
		return maYeuCau;
	}
	public void setMaYeuCau(int maYeuCau) {
		this.maYeuCau = maYeuCau;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	public String getTenYeuCau() {
		return tenYeuCau;
	}
	public void setTenYeuCau(String tenYeuCau) {
		this.tenYeuCau = tenYeuCau;
	}
	public int getLePhi() {
		return lePhi;
	}
	public void setLePhi(int lePhi) {
		this.lePhi = lePhi;
	}
	/**
	 * @return the tinhTrang
	 */
	public String getTinhTrang() {
		return tinhTrang;
	}
	/**
	 * @param tinhTrang the tinhTrang to set
	 */
	public void setTinhTrang(String tinhTrang) {
		this.tinhTrang = tinhTrang;
	}
	/**
	 * @return the giayTo
	 */
	public String getGiayTo() {
		return giayTo;
	}
	/**
	 * @param giayTo the giayTo to set
	 */
	public void setGiayTo(String giayTo) {
		this.giayTo = giayTo;
	}
}
